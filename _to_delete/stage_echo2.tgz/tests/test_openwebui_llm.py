"""Tests for the Open WebUI LLM provider."""

import pytest

from echo.llm import LLMConfig, get_llm
from echo.llm.openwebui import OpenWebUILLM, _normalize_base_url

ENV_VARS = [
    "OPENWEBUI_BASE_URL",
    "OPENWEBUI_API_KEY",
    "ECHO_LLM_BASE_URL",
    "ECHO_LLM_API_KEY",
]


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    for var in ENV_VARS:
        monkeypatch.delenv(var, raising=False)


def _config(**kwargs):
    kwargs.setdefault("provider", "openwebui")
    kwargs.setdefault("model", "qwen3:14b")
    return LLMConfig(**kwargs)


def test_openwebui_registered_and_api_suffix():
    llm = get_llm(_config(base_url="http://openwebui.local:3000"))
    assert isinstance(llm, OpenWebUILLM)
    assert llm.base_url == "http://openwebui.local:3000/api"


def test_api_suffix_not_doubled():
    llm = OpenWebUILLM(_config(base_url="http://openwebui.local:3000/api/"))
    assert llm.base_url == "http://openwebui.local:3000/api"


def test_normalize_handles_path_prefix():
    assert _normalize_base_url("https://ai.corp.in/webui/") == "https://ai.corp.in/webui/api"


def test_env_base_url(monkeypatch):
    monkeypatch.setenv("OPENWEBUI_BASE_URL", "http://owui:8080")
    assert OpenWebUILLM(_config()).base_url == "http://owui:8080/api"


def test_openwebui_env_beats_generic_env(monkeypatch):
    monkeypatch.setenv("OPENWEBUI_BASE_URL", "http://owui:8080")
    monkeypatch.setenv("ECHO_LLM_BASE_URL", "http://other:1111/v1")
    assert OpenWebUILLM(_config()).base_url == "http://owui:8080/api"


def test_generic_env_fallback(monkeypatch):
    monkeypatch.setenv("ECHO_LLM_BASE_URL", "http://shared-llm:3000")
    assert OpenWebUILLM(_config()).base_url == "http://shared-llm:3000/api"


def test_default_base_url():
    assert OpenWebUILLM(_config()).base_url == "http://localhost:3000/api"


def test_api_key_from_config():
    llm = OpenWebUILLM(_config(base_url="http://owui:3000", api_key="sk-owui-cfg"))
    assert llm.client.api_key == "sk-owui-cfg"


def test_api_key_from_env(monkeypatch):
    monkeypatch.setenv("OPENWEBUI_API_KEY", "sk-owui-env")
    monkeypatch.setenv("ECHO_LLM_API_KEY", "sk-generic")
    llm = OpenWebUILLM(_config(base_url="http://owui:3000"))
    assert llm.client.api_key == "sk-owui-env"


def test_api_key_generic_fallback(monkeypatch):
    monkeypatch.setenv("ECHO_LLM_API_KEY", "sk-generic")
    llm = OpenWebUILLM(_config(base_url="http://owui:3000"))
    assert llm.client.api_key == "sk-generic"


def test_missing_api_key_warns_not_raises(caplog):
    llm = OpenWebUILLM(_config(base_url="http://owui:3000"))
    with caplog.at_level("WARNING"):
        client = llm.client
    assert client.api_key == "not-needed"
    assert any("Open WebUI API key" in r.message for r in caplog.records)


def test_client_base_url_points_at_api():
    llm = OpenWebUILLM(_config(base_url="http://owui:3000", api_key="k"))
    # the OpenAI SDK appends /chat/completions to this
    assert str(llm.client.base_url).rstrip("/") == "http://owui:3000/api"


def test_open_model_capability_flags():
    llm = OpenWebUILLM(_config(base_url="http://owui:3000"))
    assert llm._uses_max_completion_tokens() is False
    assert llm._supports_reasoning_effort() is False
    assert llm._is_reasoning_model() is False
